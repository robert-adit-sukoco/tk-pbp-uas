

import 'dart:convert';

import 'form_add.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;



void main() {
  runApp(MaterialApp(
    title: "Belajar Form Flutter",
    home: BelajarForm(),
  ));
}

class BelajarForm extends StatefulWidget {
  static final app = _BelajarFormState();

  @override
  _BelajarFormState createState() => app;
}



class _BelajarFormState extends State<BelajarForm> {
  final _formKey = GlobalKey<FormState>();

  double nilaiSlider = 1;
  String _nama = "";
  bool first = true;
  int id = 0;
  List<Widget> tempwid = [];

  void deleteWidget(MyCards removed) async{
    Navigator.pop(context);
    Future<void> deletedata() async{
      String id = removed.task_id;
      print(id);
      var url = 'http://pbp-uas-backend.herokuapp.com/delete_task?task_id='+id;
      try{
        final response = await http.delete(Uri.parse(url));
        print("delete succes");
      }catch(error){
        print(error);
      }
    }
    await deletedata();
    setState(() {
      ;
    });
  }

  showAlertDialog(BuildContext context, MyCards removed) {

    // set up the buttons
    Widget cancelButton = TextButton(
      child: Text("Cancel"),
      onPressed:  () {
        Navigator.pop(context);
      },
    );
    Widget continueButton = TextButton(
      child: Text("Continue"),
      onPressed:  () {
        deleteWidget(removed);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("AlertDialog"),
      content: Text("Would you like to continue learning how to use Flutter alerts?"),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  Future<String> fetchData() async{
    const url = 'http://pbp-uas-backend.herokuapp.com/get_subjects_tasks?subject_id=subject03';
    tempwid = [
      ElevatedButton(
        child: Text(
          "Add Task",
          style: TextStyle(
            fontSize: 16,
            color: Colors.black,
            fontWeight: FontWeight.w800,
          ),
        ),
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all<Color>(Colors.indigo),
          padding: MaterialStateProperty.all<EdgeInsetsGeometry>(EdgeInsets.all(20)),
        ),
        onPressed: () {
          Navigator.of(context).push(MaterialPageRoute(
            builder: (context) => FormAddTask("subject03"),
          ));
        },
      ),
      SizedBox(height: 20,)
    ];
    try {
      final response = await http.get(Uri.parse(url));
      List<dynamic> data = jsonDecode(response.body);
      for(Map<String, dynamic> element in data){
        String temp = element['description'];
        print(temp);
        var datetime = DateTime.parse(element['deadline']);
        print(datetime.day.toString());

        tempwid.add(new MyCards(element['task_name'], element['description'], datetime.year.toString(), datetime.month.toString(), datetime.day.toString(), datetime.hour.toString(), datetime.minute.toString(), datetime.second.toString(), element['task_id'], element['subject_fkey_id']));

      }
    }catch(error){
      print(error);

    }
    return "succes";
  }

  @override
  void initState() {
    tempwid = [];
  }

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text("BelajarFlutter.com"),
      ),
      body: FutureBuilder<String>(
      future: fetchData(),
      builder: (context, AsyncSnapshot<String> snapshot){
        if(snapshot.hasData){
          return Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.all(20.0),
                child: Column(
                  children: tempwid,
                ),
              ),
            ),
          );
        }else{
          return CircularProgressIndicator();
        }
      }
      ),
    );
  }
}

class buildButton extends StatelessWidget {
  String id = '';
  String nama = '';

  buildButton(String nama, String id) {
    this.nama = nama;
    this.id = id;
  }

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      child: Text(
        this.nama,
        style: TextStyle(color: Colors.white),
      ),
      style: ButtonStyle(
        backgroundColor: MaterialStateProperty.all<Color>(Colors.indigoAccent),
      ),
      onPressed: () {
        ;
      },
    );
  }

}

class MyCards extends StatelessWidget {
  String task_id = '';
  String subject_fkey = '';
  String task_name = '';
  String description = '';
  String year = '';
  String month = '';
  String day = '';
  String hour = '';
  String minute = '';
  String second = '';

  MyCards(String task_name, String description,   String year , String month ,String day , String hour ,String minute, String second, String task_id, String subject_fkey, ){
    this.task_name = task_name;
    this.task_id = task_id;
    this.subject_fkey = subject_fkey;
    this.task_name = task_name;
    this.description = description;
    this.year = year;
    this.month = month;
    this.day = day;
    this.hour = hour;
    this.minute = minute;
    this.second = second;
  }


  @override
  Widget build(BuildContext context) {
    return Card(
      shadowColor: Colors.indigo,
      elevation: 8,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                flex: 9,
                child: Container(
                  alignment: Alignment.center,
                  height: 60,
                  child: Text(
                    task_name,
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: Colors.indigo,
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
              ),
            ],
          ),
          Container(
            decoration: BoxDecoration(),
            padding: EdgeInsets.all(16),

            child: Column(
              children: [
                const SizedBox(height: 4),
                Align(
                  child: Text(
                    'Deskripsi',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                      fontWeight: FontWeight.w800,
                      backgroundColor: Colors.white,
                    ),
                  ),
                  alignment: Alignment.centerLeft,
                ),
                const SizedBox(height: 24),
                Align(
                  child: Row(
                    children: [
                      Text(
                        'Deadline: ',
                        style: TextStyle(
                          fontSize: 20,
                          color: Colors.black,
                          fontWeight: FontWeight.w800,
                          backgroundColor: Colors.white,
                        ),
                      ),
                      Text(
                        year+"-"+month+"-"+day+" "+hour+":"+minute,
                        style: TextStyle(
                          fontSize: 20,
                          color: Colors.red,
                          fontWeight: FontWeight.w800,
                          backgroundColor: Colors.white,
                        ),
                      ),
                      ],

                ),
                  alignment: Alignment.centerLeft,
                ),
                Divider(color: Colors.white70),
                const SizedBox(height: 24),
                Align(
                    child: Container(
                    height: 300,
                    child: SingleChildScrollView(
                      child: Text(
                        description,
                        style: TextStyle(
                          fontSize: 20,
                          color: Colors.black,
                          fontWeight: FontWeight.w800,
                          backgroundColor: Colors.white,
                        ),
                      ),
                    ),
                  ),
                    alignment: Alignment.centerLeft,
                ),
              ],
            ),
          ),
          Row(
            children: [
              Expanded(
                flex: 9,
                child: Container(
                  alignment: Alignment.center,
                  height: 70,
                  child: Row(
                    children: [
                      const SizedBox(width: 10,),
                      RaisedButton(
                        child: Text(
                          "Edit",
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.black,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        color: Colors.blue,
                        onPressed: () {
                          ;
                        },
                      ),
                      const SizedBox(width: 10,),
                      RaisedButton(
                        child: Text(
                          "Delete",
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.black,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        onPressed: (){
                          BelajarForm.app.showAlertDialog(context, this);
                        },
                        color: Colors.red,
                      ),
                      const SizedBox(width: 10,),
                      RaisedButton(
                        child: Text(
                          "Submissions",
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.black,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        onPressed: () {
                          ;
                        },
                        color: Colors.grey,
                      ),
                    ],
                  ),
                  decoration: BoxDecoration(
                    color: Colors.indigo,
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.vertical(),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),

    );
  }
}
