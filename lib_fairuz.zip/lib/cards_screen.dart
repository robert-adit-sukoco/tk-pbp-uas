

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';



void main() {
  runApp(MaterialApp(
    title: "Belajar Form Flutter",
    home: BelajarForm(),
  ));
}

class BelajarForm extends StatefulWidget {
  static final app = _BelajarFormState();

  @override
  _BelajarFormState createState() => app;
}

class _BelajarFormState extends State<BelajarForm> {
  final _formKey = GlobalKey<FormState>();

  double nilaiSlider = 1;
  String _nama = "";
  List<Widget> _columnwidgets = [];
  List<Widget> _temp = [];
  bool first = true;
  int id = 0;

  void updateNama(String nama) {

    setState(() {
      _nama = nama;
    });
  }

  void deleteWidget(Widget removed){
    Navigator.pop(context);
    setState(() {
      _temp.remove(removed);
    });
  }
  void updateWidget(String nama) {
    setState(() {
      _temp.add(new MyCards(nama));
    });
  }

  void resetInput() {

    setState(() {
      _temp = [];
    });
  }

  showAlertDialog(BuildContext context, Widget removed) {

    // set up the buttons
    Widget cancelButton = TextButton(
      child: Text("Cancel"),
      onPressed:  () {
        Navigator.pop(context);
      },
    );
    Widget continueButton = TextButton(
      child: Text("Continue"),
      onPressed:  () {
        deleteWidget(removed);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("AlertDialog"),
      content: Text("Would you like to continue learning how to use Flutter alerts?"),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  @override
  Widget build(BuildContext context) {



    Widget temp = Scaffold(
      appBar: AppBar(
        title: Text("BelajarFlutter.com"),
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.all(20.0),
            child: OrientationBuilder(
                builder: (context, orientation) {
                  return MediaQuery
                      .of(context)
                      .orientation == Orientation.landscape ? buildLandscape(
                  ) : buildPortrait();

                }
            ),
          ),
        ),
      ),
    );


    return temp;
  }

  Widget buildLandscape(){
    _columnwidgets = [
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: TextFormField(
          decoration: new InputDecoration(
            hintText: "Masukan Input",
            labelText: "Input Anda",
            icon: Icon(Icons.input),
            border: OutlineInputBorder(
                borderRadius: new BorderRadius.circular(5.0)),
          ),
          onChanged: (String value){
            _nama = value;
          },
          validator: (value) {
            if (value != null) {
              return 'Nama tidak boleh kosong';
            }
            return null;
          },
        ),
      ),
      RaisedButton(
        child: Text(
          "Submit",
          style: TextStyle(color: Colors.white),
        ),
        color: Colors.blue,
        onPressed: () {
          updateWidget(_nama);
          print(_nama);
        },
      ),

      RaisedButton(
        child: Text(
          "Reset",
          style: TextStyle(color: Colors.white),
        ),
        color: Colors.blue,
        onPressed: () {
          resetInput();
        },
      ),
      Text('Hasil Input:'),
    ];
    print("GG");
    int size = _temp.length;
    for(int i = 0; i < size; i++){
      if(i%2 == 1){
        Widget temprow = Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Expanded(
                flex: 5,
                child: _temp[i-1]),
            Expanded(
                flex: 5,
                child: _temp[i])
          ],
        );
        _columnwidgets.add(temprow);
      }
    }
    if(size%2 == 1){
      Widget temprow = Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Expanded(
              flex: 5,
              child: _temp[size-1]),
          Expanded(
              flex: 5,
              child: SizedBox())
        ],
      );
      _columnwidgets.add(temprow);
    }
    return Column(
      children: _columnwidgets,
    );

  }

  Widget buildPortrait(){
    _columnwidgets = [
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: TextFormField(
          decoration: new InputDecoration(
            hintText: "Masukan Input",
            labelText: "Input Anda",
            icon: Icon(Icons.input),
            border: OutlineInputBorder(
                borderRadius: new BorderRadius.circular(5.0)),
          ),
          onChanged: (String value){
            _nama = value;
          },
          validator: (value) {
            if (value != null) {
              return 'Nama tidak boleh kosong';
            }
            return null;
          },
        ),
      ),
      RaisedButton(
        child: Text(
          "Submit",
          style: TextStyle(color: Colors.white),
        ),
        color: Colors.blue,
        onPressed: () {
          updateWidget(_nama);
          print(_nama);
        },
      ),

      RaisedButton(
        child: Text(
          "Reset",
          style: TextStyle(color: Colors.white),
        ),
        color: Colors.blue,
        onPressed: () {
          resetInput();
        },
      ),
      Text('Hasil Input:'),
    ];

    int size = _temp.length;
    for(int i = 0; i < size; i++){
      _columnwidgets.add(_temp[i]);
    }
    return Column(
      children: _columnwidgets,
    );

  }

}

class MyCards extends StatelessWidget {
  String nama = '';

  MyCards(String nama){
    this.nama = nama;
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      shadowColor: Colors.indigo,
      elevation: 8,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                flex: 9,
                child: Container(
                  alignment: Alignment.center,
                  height: 60,
                  child: Text(
                    nama,
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: Colors.indigo,
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
              ),
            ],
          ),
          Container(
            decoration: BoxDecoration(),
            padding: EdgeInsets.all(16),

            child: Column(
              children: [
                const SizedBox(height: 4),
                Text(
                  'Deskripsi',
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                    fontWeight: FontWeight.w800,
                    backgroundColor: Colors.white,
                  ),
                ),
                Divider(color: Colors.white70),
                const SizedBox(height: 24),
                Container(
                  height: 300,
                  child: SingleChildScrollView(
                    child: Text(
                      'Lorem ipsum dolor sit a In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before the final copy is',
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.black,
                        fontWeight: FontWeight.w800,
                        backgroundColor: Colors.white,
                      ),
                    ),
                  ),
                ),

              ],
            ),
          ),
          Row(
            children: [
              Expanded(
                flex: 9,
                child: Container(
                  alignment: Alignment.center,
                  height: 70,
                  child: Row(
                    children: [
                      const SizedBox(width: 10,),
                      RaisedButton(
                        child: Text(
                          "Edit",
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.black,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        color: Colors.blue,
                        onPressed: () {
                          ;
                        },
                      ),
                      const SizedBox(width: 10,),
                      RaisedButton(
                        child: Text(
                          "Delete",
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.black,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        onPressed: (){
                          BelajarForm.app.showAlertDialog(context, this);
                        },
                        color: Colors.red,
                      ),
                      const SizedBox(width: 10,),
                      RaisedButton(
                        child: Text(
                          "Submissions",
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.black,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        onPressed: () {
                          ;
                        },
                        color: Colors.grey,
                      ),
                    ],
                  ),
                  decoration: BoxDecoration(
                    color: Colors.indigo,
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.vertical(),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),

    );
  }
}