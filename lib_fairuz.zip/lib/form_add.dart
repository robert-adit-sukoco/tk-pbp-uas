import 'dart:convert';

import 'form_add.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:datetime_picker_formfield/datetime_picker_formfield.dart' as date;

class FormAddTask extends StatefulWidget {
  String subject_fkey = '';
  static var app;

  FormAddTask(String subject_fkey){
    this.subject_fkey = subject_fkey;
    app = _FormAddTask(subject_fkey);
  }

  @override
  _FormAddTask createState() => app;
}

class _FormAddTask extends State<FormAddTask> {
  final _formKey = GlobalKey<FormState>();

  late DateTime? _dateTime;
  late TimeOfDay time;

  String picked = '';

  String task_id = '';
  String subject_fkey = '';
  String task_name = '';
  String description = '';
  String year = '';
  String month = '';
  String day = '';
  String hour = '';
  String minute = '';
  String second = '';

  _FormAddTask(String subject_fkey){
    this.subject_fkey = subject_fkey;
  }

  _pickdate() async{
    DateTime? temp = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(DateTime.now().year-5),
        lastDate: DateTime(DateTime.now().year+5),
    );
    print(temp.toString());
    setState(() {
      _dateTime = temp;
      picked = temp.toString();
    });
  }

  _picktime() async{
    TimeOfDay? temp = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.now()
    );
    print(temp!.hour);
    int hour = temp.hour;
    int minutes = temp.minute;

    print(_dateTime.toString());
    setState(() {
      _dateTime = new DateTime(_dateTime!.year, _dateTime!.month, _dateTime!.day, hour, minutes);
      picked = _dateTime.toString();
      time = temp;
    });
  }

  void createTask() async{
    Future<void> createdata() async{

      var url = "https://pbp-uas-backend.herokuapp.com/create_task?task_id="+task_name+subject_fkey+"&subjectid="+subject_fkey+"&desc="+description+"&dd"+_dateTime!.day.toString()+"&mm="+_dateTime!.month.toString()+"&yy="+_dateTime!.year.toString()+"&hh="+_dateTime!.hour.toString()+"&mm="+_dateTime!.minute.toString()+"&ss=00";
      try{
        final response = await http.post(Uri.parse(url));
        print("create succes");
      }catch(error){
        print(error);
      }
    }
    setState(() {
      ;
    });
    createdata();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Add Task"),
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.all(20.0),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    decoration: new InputDecoration(
                      hintText: "Input Anda",
                      labelText: "Nama Task",
                      icon: Icon(Icons.task),
                      border: OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(5.0)),
                    ),
                    onChanged: (String value){
                      task_name = value;
                    },
                    validator: (value) {
                      if (value != null) {
                        return 'Nama tidak boleh kosong';
                      }
                      return null;
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    width: 500,
                    child: TextFormField(
                      maxLines: 10,
                      decoration: new InputDecoration(

                        hintText: "Input Anda",
                        labelText: "Deskripsi",
                        icon: Icon(Icons.description),
                        border: OutlineInputBorder(
                            borderRadius: new BorderRadius.circular(5.0)),
                      ),
                      onChanged: (String value){
                        description = value;
                      },
                      validator: (value) {
                        if (value != null) {
                          return 'Nama tidak boleh kosong';
                        }
                        return null;
                      },
                    ),
                  ),
                ),
                Row(
                  children: [
                    Icon(Icons.date_range),
                    SizedBox(width: 20,),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: ElevatedButton(
                        child: Text("Date"),
                        onPressed: _pickdate,
                      ),
                    ),
                    SizedBox(width: 10,),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: ElevatedButton(
                        child: Text("Time"),
                        onPressed: _picktime,
                      ),
                    ),
                    SizedBox(width: 10,),
                    Text(picked)
                  ],
                ),
                ElevatedButton(
                  child: Text(
                    "Submit",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(Colors.indigo),
                    padding: MaterialStateProperty.all<EdgeInsetsGeometry>(EdgeInsets.all(15)),
                  ),
                  onPressed: () {
                    createTask();
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );;
  }
}
